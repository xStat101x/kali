# Linux Box — Notes

Target IP:
Hostname:

---

(Paste finding blocks here as you confirm them — template in ../references/redteam_tryout_notes.md § 7)
