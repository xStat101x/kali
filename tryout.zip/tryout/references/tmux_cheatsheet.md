# tmux Cheat Sheet

Prefix key throughout: `Ctrl+b` — press and release, then press the next key separately (not held together). `set -g mouse on` should already be in your `~/.tmux.conf` so scroll/click work normally.

---

## Sessions (the outer container — survives a disconnect)

```bash
tmux new -s <name>            # create and enter a new named session
tmux ls                       # list all sessions
tmux attach -t <name>         # reattach to a named session
```
```
Ctrl+b d                      # detach — session keeps running in the background
```
```bash
tmux kill-session -t <name>   # destroy one named session
tmux kill-server              # nuke every session (careful — this is everything, everywhere)
```

**Suggested for tonight:** one session, e.g. `tmux new -s tryout`, and just work in windows/panes inside it rather than juggling multiple sessions.

---

## Windows (tabs within a session)

```
Ctrl+b c          create a new window
Ctrl+b ,          rename the current window (type the name, Enter to confirm)
Ctrl+b n          next window
Ctrl+b p          previous window
Ctrl+b <0-9>      jump directly to window number
Ctrl+b w          show a list of all windows, arrow+Enter to pick one
Ctrl+b &          kill current window (asks for confirmation)
```

**Suggested layout for tonight:** one window per box, renamed immediately after creating it:
```
Ctrl+b c    → Ctrl+b ,  → type "linux"    → Enter
Ctrl+b c    → Ctrl+b ,  → type "windows"  → Enter
Ctrl+b c    → Ctrl+b ,  → type "notes"    → Enter
```
Named windows show up in the status bar at the bottom, so you always know where you are at a glance instead of counting unlabeled numbers.

---

## Panes (splits within a window)

```
Ctrl+b %          split vertically (side by side)
Ctrl+b "          split horizontally (stacked)
Ctrl+b <arrow>    move focus to the pane in that direction
Ctrl+b z          zoom current pane to fullscreen / unzoom (toggle — doesn't close the others)
Ctrl+b x          kill current pane (asks for confirmation)
Ctrl+b q          briefly show pane numbers on screen, then press a number to jump to it
```

`z` (zoom) is genuinely useful mid-engagement — if a scan pane is spamming output and you need your shell pane fullscreen for a second without losing the split layout, zoom it, do your work, zoom again to restore.

---

## Scrolling / copy mode (mouse should work already, this is the keyboard method)

```
Ctrl+b [          enter copy/scroll mode
↑ / ↓ / PageUp/Down   scroll around
q                 exit copy mode
```
Also how you select text to copy: arrow to the start, `Space` to begin selection, arrow to the end, `Enter` to copy into tmux's buffer (paste with `Ctrl+b ]`).

---

## When to run your logging command

Turn on logging for a pane **right after you create it, before running anything you actually care about in it** — `pipe-pane` only starts capturing from the moment you run it, not retroactively:

```
Ctrl+b :
pipe-pane -o 'cat >> ~/engagement/logs/pane_<name>.log'
```
(Type that after the `:` prompt appears, then Enter.)

Practically: every time you `Ctrl+b c` a new window or `Ctrl+b %`/`"` a new pane that you intend to do real work in — not a quick throwaway check — immediately follow it with the `pipe-pane` command above, swapping `<name>` for something descriptive (`linux_shell`, `windows_privesc`, etc.) so the log files are self-explanatory later.

**To check if a pane is actually logging** (useful if you're not sure you ran it):
```
Ctrl+b :
display-message -p '#{pane_pipe}'
```
Shows `1` if logging is active on the current pane, blank/`0` if not.

You don't need to log every pane — your `notes` window doesn't need it (that's your own typing, already saved when you save the file), and quick scratch panes for a one-off check aren't worth the overhead. Reserve it for your main exploitation shell panes on each box.
