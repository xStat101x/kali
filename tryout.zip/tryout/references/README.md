# Quick Index — where to look for what

| Stuck on... | Open |
|---|---|
| Time budget / what phase should I be in right now | `redteam_tryout_notes.md` § 1 |
| tmux logging setup | `redteam_tryout_notes.md` § 2, or `tmux_cheatsheet.md` |
| nmap / recon commands | `redteam_tryout_notes.md` § 3 |
| Linux enumeration priority / privesc checklist | `redteam_tryout_notes.md` § 4 |
| Windows enumeration priority / privesc checklist | `redteam_tryout_notes.md` § 5 |
| Exact reverse shell / listener / file transfer / AD tooling syntax | `redteam_tryout_notes.md` § 6 |
| Writing up a finding | `redteam_tryout_notes.md` § 7 |
| Web app — which vuln to try first | `redteam_tryout_notes.md` § 8 |
| Final checklist before 10pm | `redteam_tryout_notes.md` § 9 |
| tmux basics (panes/windows/sessions) | `tmux_cheatsheet.md` |

**Pre-staged payloads:** `../shells/`
**Pre-staged privesc tools:** `../tools/`
