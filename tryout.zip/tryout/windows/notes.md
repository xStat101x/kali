# Windows Box — Notes

Target IP:
Hostname:
Domain-joined? (see ../references/redteam_tryout_notes.md § 6, single-box AD note):

---

(Paste finding blocks here as you confirm them — template in ../references/redteam_tryout_notes.md § 7)
